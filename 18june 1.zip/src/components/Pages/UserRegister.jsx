import React from 'react'

function UserRegister() {
  return (
    <div>UserRegister</div>
  )
}

export default UserRegister